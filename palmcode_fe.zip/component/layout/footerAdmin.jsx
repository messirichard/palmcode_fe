export default function FooterAdmin() {
    return (
        <footer className="footer">
            <h1>Footer Admin</h1>
        </footer>
    )
}
