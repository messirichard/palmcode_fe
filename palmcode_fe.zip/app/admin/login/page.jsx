export default function adminLogin() {
    return <h1>Hello, Home page!</h1>
}
